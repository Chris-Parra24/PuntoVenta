/*
    Esta ventana será donde se visualice todo el trabajo que el Punto de venta debe de hacer
    -Ver precios, productos, reportes
*/
package vista;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import controlador.Coordinador;

public class VentanaPrincipal extends javax.swing.JFrame implements ActionListener{
    //atributos
	private javax.swing.JMenu menuOpArchivo;
    private javax.swing.JMenu menuOpEditar;
    private javax.swing.JMenu menuOpOpciones;
    private javax.swing.JMenuBar menuPrincipal;
    private javax.swing.JMenuItem opGuardar;
    private javax.swing.JMenuItem opCambiarPersonal;
    private javax.swing.JPanel panelPrincipal;
    private Dimension tamañoPantalla;
    private Rectangle pantalla;
    private Coordinador coordinador;
	//constructor
    public VentanaPrincipal() {
        initComponents();
        tamañoPantalla = Toolkit.getDefaultToolkit().getScreenSize();
        pantalla = new Rectangle(tamañoPantalla);
        setBounds(pantalla);
    }

    private void initComponents() {

        panelPrincipal = new javax.swing.JPanel();
        menuPrincipal = new javax.swing.JMenuBar();
        menuOpArchivo = new javax.swing.JMenu();
        opGuardar = new javax.swing.JMenuItem();
        opCambiarPersonal = new javax.swing.JMenuItem();
        menuOpEditar = new javax.swing.JMenu();
        menuOpOpciones = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Punto Venta");
        setMinimumSize(new java.awt.Dimension(946, 489));
        setSize(new java.awt.Dimension(946, 489));
        

        panelPrincipal.setBackground(java.awt.Color.white);
        panelPrincipal.setLayout(null);
        getContentPane().add(panelPrincipal);
        panelPrincipal.setBounds(0, 0, 950, 490);

        menuOpArchivo.setText("Archivo");
        menuOpArchivo.setToolTipText("");

        opGuardar.setText("Guardar");
        menuOpArchivo.add(opGuardar);

        menuPrincipal.add(menuOpArchivo);

        menuOpEditar.setText("Editar");
        menuPrincipal.add(menuOpEditar);
        
        menuOpOpciones.setText("Opciones");
        opCambiarPersonal.setText("Cambiar usuario");
        opCambiarPersonal.addActionListener(this);
        
        menuOpOpciones.add(opCambiarPersonal);
        menuPrincipal.add(menuOpOpciones);
        

        setJMenuBar(menuPrincipal);

        pack();
    }
    //otros metodos que estarán dentro de nuestra ventana principal
    //metodo action performed
    public void actionPerformed(ActionEvent evento) {
    	if(evento.getSource()==opCambiarPersonal) {
    		//debera de aparecer la ventana de login otra vez para que la persona cambie de turno
    		coordinador.mostrarLogin();
    	}
    }
    
    //setter and getter
    public void setCoordinador(Coordinador coordinador) {
    	this.coordinador=coordinador;
    }
    public void asignarPrivilegios(int rol) {
    	//validamos el rol
    	//el rol si es 1 entonces es administrador y tiene todos los privilegios y puede hacer de todas las opciones
    	if(rol == 1) {
    		opGuardar.setEnabled(true);
    	}else {
    		opGuardar.setEnabled(false);
    	}
    }

}
